﻿# QueueTrigger - C<span>#</span>

The `QueueTrigger` makes it incredibly easy to react to new Queues inside of Azure Queue Storage. This sample demonstrates a simple use case of processing data from a given Queue using C#.

## How it works

For a `QueueTrigger` to work, you must provide a queue name that defines the queue messages will be read from.

## Learn more

<TODO> Documentation